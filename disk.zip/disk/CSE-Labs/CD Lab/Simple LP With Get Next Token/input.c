main () {
	char apple, banana, elephant;
	int cat, dog;
	cat = 5;
}