select empName, to_char(dob, 'YEAR') from Employee;
select empName, to_char(dob, 'Year') from Employee;
select empName, to_char(dob, 'year') from Employee;