#include <stdio.h>
int main(int argc, char const *argv[]) {
	printf("Hello world!\nGoodbye world!\n");
	return 0;
}