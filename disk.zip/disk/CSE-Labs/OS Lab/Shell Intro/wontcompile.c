#include <stdio.h>
#include <stdlib.h>
int main(int argc, char const *argv[]) {
	char *string = (char *)malloc(100 * sizeof(char));
	printf("Enter something: ");
	scanf(" %s", string);
	if let nope = "nope" {
		printf("NOPE\n");
	}
	return -666;
}