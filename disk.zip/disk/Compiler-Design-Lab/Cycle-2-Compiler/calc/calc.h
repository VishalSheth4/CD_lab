#define IDENTIFIER 1
#define ADD_OP 2
#define MUL_OP 3
#define SUB_OP 4
#define EQU_OP 5
#define SEMIC 6
#define KEYWORD 7
#define DIGIT 8
