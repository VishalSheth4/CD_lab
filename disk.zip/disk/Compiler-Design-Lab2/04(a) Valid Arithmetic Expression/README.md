## Compiling this Program

```sh 
yacc -d -o program.c program.y
gcc program.c
./a.out
```
