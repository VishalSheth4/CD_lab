##Steps to compile
```sh
gcc typechecking.c
./a.out
```

## Output

```
Enter the expression And place ; at the end
Press Ctrl-Z to terminate
a+b+c

 Identifier: a
 Identifier: b
Arithmetic Operator: +
 Identifier: c
```
