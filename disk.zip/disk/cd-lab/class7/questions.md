1. Write a flex program that adds line numbers to a given file and displays the same to standard output.
2. Write a program to extract the comment lines from a C program and display the same to standard output.
