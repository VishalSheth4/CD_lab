#include <iostream>

using namespace std;

int main(){
	int a,b; //input variables
	cin >> a >> b; //take input from stdin
	cout << a+b*a << endl;
	/*
	cout << a+b;
	*/
	return 0;
}