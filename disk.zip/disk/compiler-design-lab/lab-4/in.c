#include <stdio.h>

void main(){
    float ab123;
    char a;
    char b123;
    char c;
    int ab[5];
    int abc[2];
    int ca[7];
    int ac[4];
    
    scanf("%c",&c);
    scanf("%c",&a)
    for( a = 0; a < 5 ;a++)
        printf("%d ", a);
    return 0;
}