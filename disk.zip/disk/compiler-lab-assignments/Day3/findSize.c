#include <stdio.h>

int main()
{
	int a;
	int b;
	float f1;
	float f2 = 3.5;
	float f3 = 12.7;
	char ch = 'a';
	double d = 3.1416;
	double e = 2.7132304;
	long l = 12133;

	return 0;
}
