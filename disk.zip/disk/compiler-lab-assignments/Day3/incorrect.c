#include <stdio.h>
int main()
{
	printf("No return!");
}