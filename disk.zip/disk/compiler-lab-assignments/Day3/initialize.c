int a;
int b = 21;
float c;
long d = 1212;
char ch;
