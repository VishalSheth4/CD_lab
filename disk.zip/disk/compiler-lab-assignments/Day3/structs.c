struct car
{
	int tyres;
	char *make;
	notAType n;
}

typedef struct myTypes types
{
	float f;
	int i;
	imnotatype n;
	char c;
	double d;
	long l;
	short s;
	bool b; // bool is not an inbuilt datatype in C
}
