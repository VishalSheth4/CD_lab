int hello;
int i;
int who;
char ji;
float hello;
int aaaa;
char kkkk;
float jhhjhn;
