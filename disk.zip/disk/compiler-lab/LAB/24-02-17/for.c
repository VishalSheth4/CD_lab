for(i=0; i<90; i+=9){
	printf("hello world");
}
