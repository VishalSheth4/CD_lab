1. Write the Lex Program to find the token and its count from input file for the following.
	a. Identifier
	b. number
	c. Whitespace ( delimiter = space / tab / newline )
	d. Assignment symbol ( := )
	e. Operator Symbol ( + , - , *, / )

2. Write the Lex Program to find the token and its count from input file for the following.
	a. Keyword ( if, then, else, for, while, int, float, real )
	b. Relational operator symbol ( < , <=, > , >=, <>, = )
	c. Uppercase and Lowercase letter
	d. Special characters ( ! , @ , #, $ , %, ^, &, * , () )
	e. Characters, words and lines
