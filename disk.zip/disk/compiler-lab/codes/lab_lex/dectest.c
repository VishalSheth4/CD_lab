int hello;
int ji;
int a;
float b;
{int i}
int bla;
hello world!
